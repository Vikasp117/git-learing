package com.gitlearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitlearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitlearningApplication.class, args);
	}

}
